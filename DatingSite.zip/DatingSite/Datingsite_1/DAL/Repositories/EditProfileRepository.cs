﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repositories
{
    public class EditProfileRepository
    {
        public static void EditUser(int loginID, int userID, string firstname, string lastname,
        string phone, int age, int gender, string email, int privat, string city, int preferedeGender,string loginName, string password)
        {
            using (var context = new DatabaseEntities())
            {
                User user = context.Users.FirstOrDefault(x => x.UserID == userID);
                Login login = context.Logins.FirstOrDefault(x => x.LoginID == loginID);

                user.FirstName = firstname;
                user.LastName = lastname;
                user.Phone = phone;
                user.Age = age;
                user.Phone = phone;
                user.Age = age;
                user.Gender = gender;
                user.Email = email;
                user.Private = privat;
                user.City = city;
                user.PreferedGender = preferedeGender;
                login.LoginName = loginName;
                login.Password = password;
                context.SaveChanges();
            }
        }

        public static void AddProfileImage(int userID, byte[] profilImage)
        {
            using (var context = new DatabaseEntities())
            {
                
                 Image i = new Image
                {
                    UserID = userID,
                    Picture = profilImage
                };

                context.Images.Add(i);
                context.SaveChanges();
            }
        }

        public static void EditProfileImage(int userID, byte[] profilImage)
        {
            using (var context = new DatabaseEntities())
            {
                Image image = context.Images.FirstOrDefault(x => x.UserID == userID);
                image.Picture = profilImage;
                context.SaveChanges();
            }
        }


        public static Login ValidateUsername(int loginID, string username)
        {
            using (var context = new DatabaseEntities()) //Denna kommentar simulerar en ändring i koden! 
            {
                Login login = context.Logins.FirstOrDefault(x => x.LoginID == loginID);
                if (login.LoginName.Equals(username))
                {
                    return null;
                }
                return context.Logins.FirstOrDefault(x =>
                    x.LoginName.Equals(username));
            }
        }

   
   
    }
}