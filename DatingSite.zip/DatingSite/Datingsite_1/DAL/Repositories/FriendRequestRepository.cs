﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repositories
{
    public class FriendRequestRepository
    {
        //Kollar så inte personerna redan är vänner eller har en friendrequest som väntar på svar
        public static FriendRequest ValidateFriendRequest(int userID, int friendID)
        {
            using (var context = new DatabaseEntities())
            {
                    return context.FriendRequests.FirstOrDefault(x =>
                    x.UserID.Equals(userID) &&
                    x.FriendID.Equals(friendID) ||
                    x.UserID.Equals(friendID) &&
                    x.FriendID.Equals(userID));
            }
        }

        public static void AnswerFriendRequest(int userID, int friendID, int answer)
        {
            using (var context = new DatabaseEntities())
            {
                    FriendRequest friendRequest = context.FriendRequests.FirstOrDefault(x => x.UserID == userID && x.FriendID == friendID);
                    friendRequest.Status = answer;
                    context.SaveChanges();
            }
        }
        

        public static List<FriendRequest> FriendRequests(int userID)
        {
            using (var context = new DatabaseEntities())
            {

                var result = context.FriendRequests
                    .Include(x => x.User1)
                    .Where(x => x.FriendID == userID &&
                                x.Status == 3)
                    .ToList();
                return result;
            }
        }
        
        public static void AddFriend(int userID, int friendID)
        {
            using (var context = new DatabaseEntities())
            {
                FriendRequest fr = new FriendRequest
                {
                    UserID = userID,
                    FriendID = friendID,
                    Status = 3,
                };
                context.FriendRequests.Add(fr);
                context.SaveChanges();
              }
        }

    }
}
