﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common.CommandTrees;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repositories
{
    public class UserRepository
    {
        public static List<User> GetAllUsers()
        {
            using (var context = new DatabaseEntities())
            {
                return context.Users
                    .OrderBy(x => x.FirstName)
                    .ToList();
            }
        }

        /// <summary>
        /// Hämtar alla användare som har den första bokstaven
        /// i sökningen i sitt namn och de personer som har sin
        /// profil som "Upptäckbar profil".
        /// </summary>
        /// <param name="firstLetterInFirstName"></param>
        /// <returns></returns>
        public static List<User> GetAllUsers(string firstLetterInFirstName)
        {
            using (var context = new DatabaseEntities())
            {
                return context.Users
                    .Where(x => x.FirstName.Contains(firstLetterInFirstName)
                            && x.Private.Equals(1))
                    .OrderBy(x => x.FirstName)
                    .ToList();
            }
        }

        /// <summary>
        /// Returnerar en användare genom att matcha användarnamnet i tabellen "Login".
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public static User GetUser(string username)
        {
            using (var context = new DatabaseEntities())
            {
                return context.Users.FirstOrDefault(x =>
                    x.Login.LoginName.Equals(username));
            }
        }
        
     
        
      
        public static Login GetLogin(string username)
        {
            using (var context = new DatabaseEntities())
            {
                return context.Logins.FirstOrDefault(x =>
                    x.LoginName.Equals(username));
            }
        }

        public static Image GetImage(int userID)
        {
            using (var context = new DatabaseEntities())
            {
                return context.Images.FirstOrDefault(x =>
                    x.UserID.Equals(userID));
            }
        }

     
        /// <summary>
        /// Returnerar en användare baserat på det UserID som skickas in.
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public static User GetUser(int userID)
        {
            using (var context = new DatabaseEntities())
            {
                return context.Users.FirstOrDefault(x =>
                    x.UserID.Equals(userID));
            }
        }

        // visar användarens vänförfrågningar.
        /*
        public static List<User> Requestlist(int userID)
        {
            using (var context = new DatabaseEntities())
            { ej klar -
                var lista = context.FriendRequests
                    .Where(x => x.UserID == userID)
                    .Where(x => x.Status == 3)
                    .Join

            }
        } */ 

        // Status: 1 betyder ja, 2 betyder Nej, 3 = väntar på svar.
        public static List<User> GetFriends(int userID)
        {
            using (var context = new DatabaseEntities())
            {
                var friendlistForuser = context.FriendRequests.Where(x =>
                    x.UserID.Equals(userID)
                    && x.Status.Equals(2));

                var friendlist = new List<User>();

                foreach (var item in friendlistForuser)
                {
                    friendlist.Add(GetUser(item.FriendID));
                }
                return friendlist.ToList();

            }
        }

    }
}
