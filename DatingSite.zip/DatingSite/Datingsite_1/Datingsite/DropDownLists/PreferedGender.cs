﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Datingsite.DropDownLists
{
    public class PreferedGender
    {
        public int PreferedGenderID { get; set; }
        public string PreferedGenderName { get; set; }
    }
}
