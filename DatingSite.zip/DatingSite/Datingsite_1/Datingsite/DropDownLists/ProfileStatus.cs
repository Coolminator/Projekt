﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Datingsite.DropDownLists
{
    public class ProfileStatus
    {
        public int ProfileID { get; set; }
        public string Status { get; set; }
    }
}