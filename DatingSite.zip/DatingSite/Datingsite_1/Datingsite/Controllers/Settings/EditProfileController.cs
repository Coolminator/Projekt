﻿
using System.IO;
using System.Reflection.Emit;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Web.UI.WebControls;
using DAL;
using DAL.Repositories;
using Datingsite.Models;
using Datingsite.Models.UserProfileModel;

namespace Datingsite.Controllers.UserProfile
{
    [Authorize] //Om användaren inte är inloggad så öppnas sidan för att logga in!
    //Kolla i Web.config --> system.web --> authentication
    public class EditProfileController : Controller
    {
        //GET: UserProfile
        public ActionResult EditProfile()
        {
            var model = new HomeIndexViewModel();
            model.User = GetLoggedInUser();
            model.Image = UserRepository.GetImage(model.User.UserID);
            model.FriendRequests = FriendRequestRepository.FriendRequests(model.User.UserID);
            model.LoggedInUser = GetLoggedInUser();
            model.Login = GetLoggedLogin();

            return View(model);
        }

            

        [HttpPost]
        public ActionResult EditProfile(HomeIndexViewModel model)
        {
            model.User = GetLoggedInUser();
            model.Login = GetLoggedLogin();
            if (ModelState.IsValid)
            {
                var newUsername = EditProfileRepository.ValidateUsername(model.Login.LoginID, model.LoginName);
                if (newUsername != null)
                {
                    ModelState.AddModelError("", "Användarnamnet måste vara unikt");
                    return View(model);
                }
                EditProfileRepository.EditUser(model.Login.LoginID, model.User.UserID,
                model.FirstName, model.LastName, model.Phone,
                model.Age, model.Gender, model.Email, model.ProfileStatus, model.City, model.PreferedGender,
                model.LoginName,model.Password);

                FormsAuthentication.SetAuthCookie(model.LoginName, false);
                return RedirectToAction("ProfileStart", "UserProfile");
             }
            return View(model);
          }

        public ActionResult FileUpload(HttpPostedFileBase file)
        {
            if (file != null)
            {
                string pic = Path.GetFileName(file.FileName);

                string path = Path.Combine(
                                  Server.MapPath("~/ProfileImages"), pic);
                // file is uploaded
                file.SaveAs(path);

                // save the image path path to the database or you can send image 
                // directly to database
                // in-case if you want to store byte[] ie. for DB
                using (MemoryStream ms = new MemoryStream())
                {
                    var user= GetLoggedInUser();
                    file.InputStream.CopyTo(ms);
                    byte[] array = ms.GetBuffer();
                    if (UserRepository.GetImage(user.UserID) == null)
                    {
                        EditProfileRepository.AddProfileImage(user.UserID, array);
                        return RedirectToAction("EditProfile", "EditProfile");
                    }
                    EditProfileRepository.EditProfileImage(user.UserID,array);
                    return RedirectToAction("EditProfile", "EditProfile");
                }

            }
            // after successfully uploading redirect the user
            return RedirectToAction("EditProfile", "EditProfile");
        }
        
        private User GetLoggedInUser()
        {
            var username = FormsAuthentication.Decrypt(Request.Cookies[FormsAuthentication.FormsCookieName].Value).Name;
            return UserRepository.GetUser(username);
        }

        private DAL.Login GetLoggedLogin()
        {
            var username = FormsAuthentication.Decrypt(Request.Cookies[FormsAuthentication.FormsCookieName].Value).Name;
            return UserRepository.GetLogin(username);
        }

   
        public ViewResult _SearchFieldPartialView()
        {
            return View("_SearchFieldPartialView");
        }

        [HttpPost]
        public ActionResult SearchResult(SearchModel model)
        {
            if (!ModelState.IsValid)
                return View("EditProfile");

            string searchQuery = model.Search.Substring(0, 1);
            return RedirectToAction("ReturnSearchResult", "Search", new { searchQuery });
            //                      Metoden                Controllern   Parametern
        }
    }
}