﻿
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.Security;
using DAL;
using DAL.Repositories;
using Datingsite.Models;


namespace Datingsite.Controllers.Friends
{
     [Authorize] //Om användaren inte är inloggad så öppnas sidan för att logga in!
                //Kolla i Web.config --> system.web --> authentication

    public class FriendsController : Controller
    {
         /*
         public static ActionResult GetFriendList(int userID)
         {
             var model = new FriendModel();
             model.User = UserRepository.GetFriends(userID);


             return View("Friend", model);
             // return UserRepository.GetFriends(userID);
         }*/

    }
}