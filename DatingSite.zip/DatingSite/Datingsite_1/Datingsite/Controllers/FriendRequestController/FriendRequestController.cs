﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DAL;
using DAL.Repositories;
using Datingsite.Models;
using Datingsite.Models.FriendsListModel;

namespace Datingsite.Controllers.FriendRequestController
{
    public class FriendRequestController : Controller
    {
        public ActionResult FriendRequest()
        {
            var model = new FriendsListModel();

            model.User = GetLoggedInUser();
            model.FriendList = FriendsListRepository.FriendsList(model.User.UserID);
            model.LoggedInUser = GetLoggedInUser();
            return View(model);
        }

        public ActionResult FriendRequestFor(int userID)
        {
            var model = new FriendsListModel();
            model.LoggedInUser = GetLoggedInUser();
            model.User = UserRepository.GetUser(userID);
            model.FriendRequests = FriendRequestRepository.FriendRequests(userID);
            return View("FriendRequest", model);
        }

        public ActionResult AnswerFriendRequest(int userID, int answer)
        {
            var user = GetLoggedInUser();
            FriendRequestRepository.AnswerFriendRequest(userID, user.UserID, answer);
            return RedirectToAction("ProfileStart", "UserProfile");
        }

        // GET: FriendRequest
        public ActionResult AddFriend(int friendID)
        {
            var user = GetLoggedInUser();
            FriendRequestRepository.AddFriend(user.UserID, friendID);
            return RedirectToAction("ProfileStart", "UserProfile");
        }

        private User GetLoggedInUser()
        {
            var username = User.Identity.Name;
            return UserRepository.GetUser(username);
        }

        public ViewResult _SearchFieldPartialView()
        {
            return View("_SearchFieldPartialView");
        }

        [HttpPost]
        public ActionResult SearchResult(SearchModel model)
        {
            if (!ModelState.IsValid)
                return View("FriendRequest");

            string searchQuery = model.Search.Substring(0, 1);
            return RedirectToAction("ReturnSearchResult", "Search", new { searchQuery });
            //                      Metoden                Controllern   Parametern
        }
    }
}